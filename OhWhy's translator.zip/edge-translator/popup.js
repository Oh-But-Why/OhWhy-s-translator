// popup.js — Edge Translator Settings Panel
(async function () {
  'use strict';

  // ── Elements ────────────────────────────────────────────

  const radios = document.querySelectorAll('input[name="source"]');
  const youdaoSection = document.getElementById('youdao-section');
  const appKeyInput = document.getElementById('youdao-appkey');
  const secretInput = document.getElementById('youdao-secret');
  const saveBtn = document.getElementById('youdao-save');
  const statusEl = document.getElementById('youdao-status');

  // ── Load config ─────────────────────────────────────────

  try {
    const config = await chrome.runtime.sendMessage({ type: 'getConfig' });
    // Set radio
    const activeRadio = document.querySelector(`input[value="${config.source}"]`);
    if (activeRadio) activeRadio.checked = true;
    toggleYoudaoSection(config.source);
    // Fill youdao fields
    appKeyInput.value = config.youdaoAppKey || '';
    secretInput.value = config.youdaoSecret || '';
  } catch (err) {
    console.error('Failed to load config:', err);
  }

  // ── Source switch ───────────────────────────────────────

  radios.forEach(radio => {
    radio.addEventListener('change', async () => {
      const source = radio.value;
      toggleYoudaoSection(source);
      // Instant save via toggle
      try {
        await chrome.runtime.sendMessage({ type: 'switchSource' });
      } catch (err) {
        console.error('Failed to switch source:', err);
      }
    });
  });

  function toggleYoudaoSection(source) {
    youdaoSection.style.display = source === 'youdao' ? 'block' : 'none';
    if (source === 'google') {
      statusEl.textContent = '';
      statusEl.className = 'status-msg';
    }
  }

  // ── Save Youdao config ──────────────────────────────────

  saveBtn.addEventListener('click', async () => {
    const appKey = appKeyInput.value.trim();
    const secret = secretInput.value.trim();

    if (!appKey || !secret) {
      showStatus('请填写 APP Key 和 Secret', 'error');
      return;
    }

    saveBtn.disabled = true;
    saveBtn.textContent = '校验中...';
    showStatus('正在校验...', '');

    try {
      const result = await chrome.runtime.sendMessage({
        type: 'saveYoudao',
        appKey,
        secret
      });

      if (result.valid) {
        showStatus('✓ 校验通过，有道翻译已就绪', 'success');
      } else {
        showStatus('✗ ' + (result.message || '校验失败，请检查 Key'), 'error');
      }
    } catch (err) {
      showStatus('✗ 保存失败：' + err.message, 'error');
    }

    saveBtn.disabled = false;
    saveBtn.textContent = '保存并校验';
  });

  function showStatus(msg, cls) {
    statusEl.textContent = msg;
    statusEl.className = 'status-msg ' + cls;
  }

})();
