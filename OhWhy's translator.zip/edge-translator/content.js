// content.js — Edge Translator Content Script
(function () {
  'use strict';

  let bubble = null;
  let isDragging = false;
  let dragOffsetX = 0;
  let dragOffsetY = 0;

  // ── Keyboard Shortcuts ──────────────────────────────────

  document.addEventListener('keydown', async (e) => {
    // Ctrl+Shift+E: translate
    if (e.ctrlKey && e.shiftKey && (e.key === 'E' || e.key === 'e')) {
      e.preventDefault();
      await doTranslate();
    }

    // Ctrl+Shift+Y: switch source
    if (e.ctrlKey && e.shiftKey && e.key === 'Y') {
      e.preventDefault();
      await doSwitchSource();
    }

    // Escape: close bubble
    if (e.key === 'Escape' && bubble) {
      removeBubble();
    }
  });

  // ── Translation ─────────────────────────────────────────

  async function doTranslate() {
    const selection = window.getSelection();
    const text = selection.toString().trim();

    if (!text) return;
    if (text.length > 5000) {
      showToast('文本过长，将截取前 5000 字符翻译');
    }

    // Check if text contains English letters
    if (!/[a-zA-Z]/.test(text)) {
      showToast('未检测到英文文本');
      return;
    }

    try {
      const response = await chrome.runtime.sendMessage({ type: 'translate', text });
      if (response.type === 'translation') {
        showBubble(text, response.text, response.source);
      } else if (response.type === 'error') {
        showToast(response.message);
      }
    } catch (err) {
      showToast('翻译失败：请检查网络连接');
    }
  }

  async function doSwitchSource() {
    try {
      const response = await chrome.runtime.sendMessage({ type: 'switchSource' });
      if (response.type === 'sourceSwitched') {
        const label = response.source === 'google' ? 'Google' : '有道';
        showToast(`已切换到 ${label}`);
      }
    } catch (err) {
      showToast('切换失败');
    }
  }

  // ── Bubble UI ────────────────────────────────────────────

  function createBubble() {
    const div = document.createElement('div');
    div.id = 'et-bubble';
    div.className = 'et-bubble';

    div.innerHTML = `
      <div class="et-header">
        <span class="et-source-label"></span>
        <button class="et-close" title="关闭">&times;</button>
      </div>
      <div class="et-body">
        <div class="et-original"></div>
        <div class="et-translation"></div>
      </div>
    `;

    // Close button
    div.querySelector('.et-close').addEventListener('click', (e) => {
      e.stopPropagation();
      removeBubble();
    });

    // Drag from header
    const header = div.querySelector('.et-header');
    header.addEventListener('mousedown', startDrag);

    document.body.appendChild(div);
    return div;
  }

  function showBubble(original, translation, source) {
    removeBubble();
    bubble = createBubble();

    // Content
    bubble.querySelector('.et-source-label').textContent = source === 'google' ? 'G' : 'Y';
    bubble.querySelector('.et-source-label').title = source === 'google' ? 'Google 翻译' : '有道翻译';
    bubble.querySelector('.et-original').textContent = original;
    bubble.querySelector('.et-translation').textContent = translation;

    // Position: below the selection
    positionBubble(bubble);

    // Click outside to close (delayed to avoid immediate close)
    setTimeout(() => {
      document.addEventListener('mousedown', onOutsideClick);
    }, 100);
  }

  function positionBubble(el) {
    const selection = window.getSelection();
    if (!selection.rangeCount) return;

    const rect = selection.getRangeAt(0).getBoundingClientRect();
    const bubbleWidth = 360;
    const bubbleHeight = el.offsetHeight || 150;
    const margin = 12;

    // Default: below selection, left-aligned
    let left = rect.left + window.scrollX;
    let top = rect.bottom + window.scrollY + margin;

    // Horizontal boundary: flip if overflows right edge
    if (left + bubbleWidth > window.innerWidth + window.scrollX) {
      left = window.innerWidth + window.scrollX - bubbleWidth - margin;
    }
    if (left < window.scrollX) {
      left = window.scrollX + margin;
    }

    // Vertical boundary: show above if too close to bottom
    if (top + bubbleHeight > window.innerHeight + window.scrollY) {
      top = rect.top + window.scrollY - bubbleHeight - margin;
    }
    if (top < window.scrollY) {
      top = window.scrollY + margin;
    }

    el.style.left = left + 'px';
    el.style.top = top + 'px';
  }

  function removeBubble() {
    if (bubble) {
      bubble.remove();
      bubble = null;
      document.removeEventListener('mousedown', onOutsideClick);
    }
  }

  function onOutsideClick(e) {
    if (bubble && !bubble.contains(e.target)) {
      removeBubble();
    }
  }

  // ── Drag ─────────────────────────────────────────────────

  function startDrag(e) {
    if (e.target.closest('.et-close')) return;
    isDragging = true;
    const rect = bubble.getBoundingClientRect();
    dragOffsetX = e.clientX - rect.left;
    dragOffsetY = e.clientY - rect.top;

    document.addEventListener('mousemove', onDrag);
    document.addEventListener('mouseup', stopDrag);
    bubble.style.transition = 'none';
    e.preventDefault();
  }

  function onDrag(e) {
    if (!isDragging || !bubble) return;
    bubble.style.left = (e.clientX - dragOffsetX) + 'px';
    bubble.style.top = (e.clientY - dragOffsetY) + 'px';
  }

  function stopDrag() {
    isDragging = false;
    document.removeEventListener('mousemove', onDrag);
    document.removeEventListener('mouseup', stopDrag);
    if (bubble) bubble.style.transition = '';
  }

  // ── Toast ────────────────────────────────────────────────

  function showToast(message) {
    const existing = document.querySelector('.et-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'et-toast';
    toast.textContent = message;
    document.body.appendChild(toast);

    requestAnimationFrame(() => toast.classList.add('et-toast--visible'));

    setTimeout(() => {
      toast.classList.remove('et-toast--visible');
      setTimeout(() => toast.remove(), 300);
    }, 2000);
  }

  // ── Commands API relay (from background) ────────────────

  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'doTranslate') doTranslate();
    if (message.type === 'doSwitchSource') doSwitchSource();
  });

})();
