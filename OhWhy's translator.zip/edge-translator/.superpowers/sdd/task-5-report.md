# Task 5 Report — Popup Settings Panel

**Status:** DONE

## Files Created

| File | Path | Size |
|------|------|------|
| popup.html | `D:\Information technology\AI\AI生成的文件\edge-translator\popup.html` | 2,218 bytes |
| popup.js | `D:\Information technology\AI\AI生成的文件\edge-translator\popup.js` | 3,127 bytes |
| popup.css | `D:\Information technology\AI\AI生成的文件\edge-translator\popup.css` | 3,882 bytes |

## Summary

All three popup files were written with the exact content specified. The popup provides:

- **Source selection** via custom-styled radio buttons (Google Translate / Youdao Translate)
- **Youdao configuration** section (APP Key + Secret fields, save-and-validate button) that shows/hides based on selected source
- **Keyboard shortcut display** (Ctrl+Shift+T for translate, Ctrl+Shift+Y for switch source)
- **Dark-themed UI** (Catppuccin Mocha-inspired palette) at 320px width

## Message Protocol

The popup communicates with `background.js` via `chrome.runtime.sendMessage`:

- `getConfig` → retrieves current source and Youdao credentials
- `switchSource` → toggles between google/youdao
- `saveYoudao` → saves APP Key + Secret, returns validation result
