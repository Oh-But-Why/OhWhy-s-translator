# Task 2 Report: background.js

**Status:** DONE

**File:** `D:\Information technology\AI\AI生成的文件\edge-translator\background.js`

**Size:** 4970 bytes

**Summary:** Created the Edge Translator Service Worker (`background.js`) with the following capabilities:

| Feature | Description |
|---|---|
| **Google Translate** | Calls `translate.googleapis.com/translate_a/single` with 5s timeout and AbortController |
| **Youdao Translate** | Calls `openapi.youdao.com/api` with SHA-256 signing (v3), 5s timeout |
| **Config storage** | Uses `chrome.storage.local` for source, youdaoAppKey, youdaoSecret |
| **Message handlers** | `translate` (EN->CN, 5000 char limit), `switchSource` (toggles google/youdao), `getConfig`, `saveYoudao` (with validation test) |
| **Error handling** | Timeout errors, HTTP errors, empty response errors, Youdao errorCode checks — all surfaced to caller |

**Verification:** File written successfully; 4970 bytes on disk, matches the specified content exactly.
