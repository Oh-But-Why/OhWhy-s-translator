# Task 3 Report — content.js

**Status:** DONE

**File:** `D:\Information technology\AI\AI生成的文件\edge-translator\content.js` (6904 bytes)

**What was done:**
- Created the content script (`content.js`) for the Edge Translator extension.
- The script is wrapped in an IIFE with `'use strict'` mode.

**Features implemented:**

| Feature | Details |
|---------|---------|
| Keyboard shortcuts | Ctrl+Shift+T (translate), Ctrl+Shift+Y (switch source), Escape (close bubble) |
| Translation | Fetches selection text, validates it contains English letters, enforces 5000-char limit, sends `translate` message to background.js |
| Source switching | Sends `switchSource` message to background.js, displays toast with new source name |
| Bubble UI | Dynamically created `#et-bubble` element with header (source label + close button) and body (original + translation text) |
| Bubble positioning | Places bubble below the text selection with boundary detection (flips above/below, clamps horizontally) |
| Drag | Bubble is draggable via the header area using mousedown/mousemove/mouseup events |
| Click-outside-to-close | Delayed (100ms) listener to prevent accidental close on the triggering click |
| Toast notifications | `showToast()` creates a temporary `.et-toast` element with fade-in/out animation, auto-removes after 2 seconds |
| Commands API relay | Listens for `doTranslate` and `doSwitchSource` messages from background.js (for Edge Commands API integration) |

**Message protocol verified:**
- Outgoing: `{ type: 'translate', text }` and `{ type: 'switchSource' }`
- Incoming: `{ type: 'translation', text, source }`, `{ type: 'error', message }`, `{ type: 'sourceSwitched', source }`
- Relay: `{ type: 'doTranslate' }` and `{ type: 'doSwitchSource' }`

**No concerns.**
