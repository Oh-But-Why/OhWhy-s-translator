# Edge 划词翻译插件 — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a Manifest V3 Edge extension that translates selected English text via Google/Youdao and shows results in a draggable bubble popup.

**Architecture:** Content script handles selection + bubble UI; Background Service Worker handles API calls + config; Popup provides settings UI. Communication via `chrome.runtime.sendMessage`.

**Tech Stack:** Manifest V3, vanilla JS, zero dependencies, zero build tools.

## Global Constraints

- Manifest V3 only
- Pure vanilla JS, no framework, no build step
- All CSS classes prefixed with `et-`
- Bubble z-index: 99999
- 5-second timeout on all translation requests
- Max text length: 5000 characters (truncate with notice)
- Config stored in `chrome.storage.local`
- Output directory: `D:\Information technology\AI\AI生成的文件\edge-translator\`

---

### Task 1: Project Scaffolding & Manifest

**Files:**
- Create: `manifest.json`
- Create: `icons/` directory with 3 placeholder PNGs

**Interfaces:**
- Produces: `manifest.json` defining all permissions, content_scripts, background, action, commands
- Produces: icon files at `icons/icon-16.png`, `icons/icon-48.png`, `icons/icon-128.png`

- [ ] **Step 1: Create manifest.json**

Write `D:\Information technology\AI\AI生成的文件\edge-translator\manifest.json`:

```json
{
  "manifest_version": 3,
  "name": "Edge Translator",
  "version": "1.0.0",
  "description": "划词翻译：框选英文 → Ctrl+Shift+T 翻译 → 气泡显示",
  "permissions": ["storage"],
  "host_permissions": [
    "https://translate.googleapis.com/*",
    "https://openapi.youdao.com/*"
  ],
  "content_scripts": [
    {
      "matches": ["<all_urls>"],
      "js": ["content.js"],
      "css": ["content.css"],
      "run_at": "document_end"
    }
  ],
  "background": {
    "service_worker": "background.js"
  },
  "action": {
    "default_popup": "popup.html",
    "default_icon": {
      "16": "icons/icon-16.png",
      "48": "icons/icon-48.png",
      "128": "icons/icon-128.png"
    }
  },
  "icons": {
    "16": "icons/icon-16.png",
    "48": "icons/icon-48.png",
    "128": "icons/icon-128.png"
  },
  "commands": {
    "translate": {
      "suggested_key": {
        "default": "Ctrl+Shift+T"
      },
      "description": "翻译选中文本"
    },
    "switch-source": {
      "suggested_key": {
        "default": "Ctrl+Shift+Y"
      },
      "description": "切换翻译源（Google ↔ 有道）"
    }
  }
}
```

- [ ] **Step 2: Generate placeholder icon PNGs**

Since we need actual PNG files, generate simple 16x16, 48x48, 128x128 solid-color PNGs with a "T" letter using a minimal approach. These will serve as placeholders until custom icons are made.

Create `icons/icon-16.png` — 16×16 teal square PNG.
Create `icons/icon-48.png` — 48×48 teal square PNG.  
Create `icons/icon-128.png` — 128×128 teal square PNG.

(Generated via a minimal base64-encoded PNG or a one-shot Node/PowerShell script — see implementation note below.)

**Implementation note for icon generation:** Use this PowerShell one-liner to create simple colored PNG placeholders:

```powershell
# Requires .NET System.Drawing
Add-Type -AssemblyName System.Drawing
$sizes = @(16, 48, 128)
foreach ($s in $sizes) {
    $bmp = New-Object System.Drawing.Bitmap($s, $s)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.Clear([System.Drawing.Color]::FromArgb(0, 150, 136))
    $font = New-Object System.Drawing.Font("Microsoft YaHei", [Math]::Floor($s * 0.55))
    $brush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
    $sf = New-Object System.Drawing.StringFormat
    $sf.Alignment = [System.Drawing.StringAlignment]::Center
    $sf.LineAlignment = [System.Drawing.StringAlignment]::Center
    $g.DrawString("T", $font, $brush, [System.Drawing.RectangleF]::new(0, 0, $s, $s), $sf)
    $bmp.Save("D:\Information technology\AI\AI生成的文件\edge-translator\icons\icon-$s.png", [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose(); $bmp.Dispose(); $font.Dispose(); $brush.Dispose()
}
```

- [ ] **Step 3: Verify manifest.json is valid JSON**

Run: `npx --yes @anthropic-ai/claude-code --print "Check that D:\Information technology\AI\AI生成的文件\edge-translator\manifest.json is valid JSON"` — or simply open in Edge to verify.

---

### Task 2: Background Service Worker — Translation & Config

**Files:**
- Create: `background.js`

**Interfaces:**
- Produces: Message handler listening for `translate`, `switchSource`, `getConfig`, `saveYuedao`
- Produces: `translateWithGoogle(text)` → Promise\<string\>
- Produces: `translateWithYoudao(text)` → Promise\<string\>
- Consumes: `chrome.storage.local` keys: `source` ("google"|"youdao"), `youdaoAppKey`, `youdaoSecret`

- [ ] **Step 1: Write background.js — config helpers**

```js
// background.js — Service Worker
const STORAGE_KEYS = {
  source: 'source',
  youdaoAppKey: 'youdaoAppKey',
  youdaoSecret: 'youdaoSecret'
};

const DEFAULT_SOURCE = 'google';

async function getConfig() {
  const result = await chrome.storage.local.get(STORAGE_KEYS);
  return {
    source: result.source || DEFAULT_SOURCE,
    youdaoAppKey: result.youdaoAppKey || '',
    youdaoSecret: result.youdaoSecret || ''
  };
}
```

- [ ] **Step 2: Write background.js — Google translator**

```js
async function translateWithGoogle(text) {
  const url = 'https://translate.googleapis.com/translate_a/single' +
    '?client=gtx&sl=en&tl=zh-CN&dt=t&q=' + encodeURIComponent(text);

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);

  try {
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeout);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    // Google returns: [[["译文","原文",null,null,1],...],null,"en"]
    if (!data || !data[0]) throw new Error('Empty response');
    return data[0].map(item => item[0]).join('');
  } catch (err) {
    clearTimeout(timeout);
    if (err.name === 'AbortError') throw new Error('翻译超时');
    throw new Error('无法连接 Google 翻译');
  }
}
```

- [ ] **Step 3: Write background.js — Youdao translator**

```js
async function translateWithYoudao(text, appKey, secret) {
  if (!appKey || !secret) {
    throw new Error('请先在设置中填写有道 APP Key 和 Secret');
  }

  const salt = Date.now().toString();
  const curtime = Math.floor(Date.now() / 1000).toString();
  const input = text.length <= 20
    ? text
    : text.substring(0, 10) + text.length + text.substring(text.length - 10);

  // sign = SHA256(appKey + input + salt + curtime + secret)
  const signStr = appKey + input + salt + curtime + secret;
  const encoder = new TextEncoder();
  const data = encoder.encode(signStr);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const sign = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

  const body = new URLSearchParams({
    q: text,
    from: 'en',
    to: 'zh-CHS',
    appKey: appKey,
    salt: salt,
    sign: sign,
    signType: 'v3',
    curtime: curtime
  });

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);

  try {
    const res = await fetch('https://openapi.youdao.com/api', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString(),
      signal: controller.signal
    });
    clearTimeout(timeout);
    const json = await res.json();
    if (json.errorCode !== '0') {
      throw new Error(`有道翻译错误: ${json.errorCode}`);
    }
    return json.translation.join('');
  } catch (err) {
    clearTimeout(timeout);
    if (err.name === 'AbortError') throw new Error('翻译超时');
    throw err;
  }
}
```

- [ ] **Step 4: Write background.js — message handler**

```js
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message).then(sendResponse);
  return true; // keep channel open for async response
});

async function handleMessage(message) {
  switch (message.type) {
    case 'translate': {
      const config = await getConfig();
      const text = message.text.trim().substring(0, 5000);
      const truncated = message.text.length > 5000;

      try {
        let translation;
        if (config.source === 'youdao') {
          translation = await translateWithYoudao(text, config.youdaoAppKey, config.youdaoSecret);
        } else {
          translation = await translateWithGoogle(text);
        }
        return {
          type: 'translation',
          text: translation + (truncated ? '\n（原文过长已截断）' : ''),
          source: config.source
        };
      } catch (err) {
        return { type: 'error', message: err.message };
      }
    }

    case 'switchSource': {
      const config = await getConfig();
      const newSource = config.source === 'google' ? 'youdao' : 'google';
      await chrome.storage.local.set({ source: newSource });
      return { type: 'sourceSwitched', source: newSource };
    }

    case 'getConfig': {
      const config = await getConfig();
      return { type: 'config', ...config };
    }

    case 'saveYoudao': {
      await chrome.storage.local.set({
        youdaoAppKey: message.appKey,
        youdaoSecret: message.secret
      });
      // Validate the key by doing a test translation
      try {
        await translateWithYoudao('test', message.appKey, message.secret);
        return { type: 'configSaved', valid: true };
      } catch (err) {
        return { type: 'configSaved', valid: false, message: err.message };
      }
    }
  }
}
```

- [ ] **Step 5: Verify background.js has no syntax errors**

Run: The file is ready for loading in Edge. No build step needed.

---

### Task 3: Content Script — Selection Detection & Bubble UI

**Files:**
- Create: `content.js`

**Interfaces:**
- Produces: Keyboard shortcut listeners (Ctrl+Shift+T, Ctrl+Shift+Y)
- Produces: Bubble DOM creation, positioning, drag, close
- Consumes: `chrome.runtime.sendMessage` for translation/switch
- Consumes: `content.css` for styling

- [ ] **Step 1: Write content.js — core setup and keyboard handling**

```js
// content.js — Content Script
(function () {
  'use strict';

  let bubble = null;
  let isDragging = false;
  let dragOffsetX = 0;
  let dragOffsetY = 0;

  // ── Keyboard Shortcuts ──────────────────────────────────

  document.addEventListener('keydown', async (e) => {
    // Ctrl+Shift+T: translate
    if (e.ctrlKey && e.shiftKey && e.key === 'T') {
      e.preventDefault();
      await doTranslate();
    }

    // Ctrl+Shift+Y: switch source
    if (e.ctrlKey && e.shiftKey && e.key === 'Y') {
      e.preventDefault();
      await doSwitchSource();
    }

    // Escape: close bubble
    if (e.key === 'Escape' && bubble) {
      removeBubble();
    }
  });

  // ── Translation ─────────────────────────────────────────

  async function doTranslate() {
    const selection = window.getSelection();
    const text = selection.toString().trim();

    if (!text) return;
    if (text.length > 5000) {
      showToast('文本过长，将截取前 5000 字符翻译');
    }

    // Check if text contains English letters
    if (!/[a-zA-Z]/.test(text)) {
      showToast('未检测到英文文本');
      return;
    }

    try {
      const response = await chrome.runtime.sendMessage({ type: 'translate', text });
      if (response.type === 'translation') {
        showBubble(text, response.text, response.source);
      } else if (response.type === 'error') {
        showToast(response.message);
      }
    } catch (err) {
      showToast('翻译失败：请检查网络连接');
    }
  }

  async function doSwitchSource() {
    try {
      const response = await chrome.runtime.sendMessage({ type: 'switchSource' });
      if (response.type === 'sourceSwitched') {
        const label = response.source === 'google' ? 'Google' : '有道';
        showToast(`已切换到 ${label}`);
      }
    } catch (err) {
      showToast('切换失败');
    }
  }
```

- [ ] **Step 2: Write content.js — bubble creation and positioning**

```js
  // ── Bubble UI ────────────────────────────────────────────

  function createBubble() {
    const div = document.createElement('div');
    div.id = 'et-bubble';
    div.className = 'et-bubble';

    div.innerHTML = `
      <div class="et-header">
        <span class="et-source-label"></span>
        <button class="et-close" title="关闭">×</button>
      </div>
      <div class="et-body">
        <div class="et-original"></div>
        <div class="et-translation"></div>
      </div>
    `;

    // Close button
    div.querySelector('.et-close').addEventListener('click', (e) => {
      e.stopPropagation();
      removeBubble();
    });

    // Drag from header
    const header = div.querySelector('.et-header');
    header.addEventListener('mousedown', startDrag);

    document.body.appendChild(div);
    return div;
  }

  function showBubble(original, translation, source) {
    removeBubble();
    bubble = createBubble();

    // Content
    bubble.querySelector('.et-source-label').textContent = source === 'google' ? 'G' : 'Y';
    bubble.querySelector('.et-source-label').title = source === 'google' ? 'Google 翻译' : '有道翻译';
    bubble.querySelector('.et-original').textContent = original;
    bubble.querySelector('.et-translation').textContent = translation;

    // Position: below the selection
    positionBubble(bubble);

    // Click outside to close (delayed to avoid immediate close)
    setTimeout(() => {
      document.addEventListener('mousedown', onOutsideClick);
    }, 100);
  }

  function positionBubble(el) {
    const selection = window.getSelection();
    if (!selection.rangeCount) return;

    const rect = selection.getRangeAt(0).getBoundingClientRect();
    const bubbleWidth = 360;
    const bubbleHeight = el.offsetHeight || 150;
    const margin = 12;

    // Default: below selection, left-aligned
    let left = rect.left + window.scrollX;
    let top = rect.bottom + window.scrollY + margin;

    // Horizontal boundary: flip if overflows right edge
    if (left + bubbleWidth > window.innerWidth + window.scrollX) {
      left = window.innerWidth + window.scrollX - bubbleWidth - margin;
    }
    if (left < window.scrollX) {
      left = window.scrollX + margin;
    }

    // Vertical boundary: show above if too close to bottom
    if (top + bubbleHeight > window.innerHeight + window.scrollY) {
      top = rect.top + window.scrollY - bubbleHeight - margin;
    }
    if (top < window.scrollY) {
      top = window.scrollY + margin;
    }

    el.style.left = left + 'px';
    el.style.top = top + 'px';
  }

  function removeBubble() {
    if (bubble) {
      bubble.remove();
      bubble = null;
      document.removeEventListener('mousedown', onOutsideClick);
    }
  }

  function onOutsideClick(e) {
    if (bubble && !bubble.contains(e.target)) {
      removeBubble();
    }
  }
```

- [ ] **Step 3: Write content.js — drag implementation**

```js
  // ── Drag ─────────────────────────────────────────────────

  function startDrag(e) {
    if (e.target.closest('.et-close')) return; // don't drag from close button
    isDragging = true;
    const rect = bubble.getBoundingClientRect();
    dragOffsetX = e.clientX - rect.left;
    dragOffsetY = e.clientY - rect.top;

    document.addEventListener('mousemove', onDrag);
    document.addEventListener('mouseup', stopDrag);
    bubble.style.transition = 'none';
    e.preventDefault();
  }

  function onDrag(e) {
    if (!isDragging || !bubble) return;
    bubble.style.left = (e.clientX - dragOffsetX) + 'px';
    bubble.style.top = (e.clientY - dragOffsetY) + 'px';
  }

  function stopDrag() {
    isDragging = false;
    document.removeEventListener('mousemove', onDrag);
    document.removeEventListener('mouseup', stopDrag);
    if (bubble) bubble.style.transition = '';
  }
```

- [ ] **Step 4: Write content.js — toast notification**

```js
  // ── Toast ────────────────────────────────────────────────

  function showToast(message) {
    // Remove existing toast
    const existing = document.querySelector('.et-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'et-toast';
    toast.textContent = message;
    document.body.appendChild(toast);

    // Trigger animation
    requestAnimationFrame(() => toast.classList.add('et-toast--visible'));

    setTimeout(() => {
      toast.classList.remove('et-toast--visible');
      setTimeout(() => toast.remove(), 300);
    }, 2000);
  }

  // ── Handle commands from browser action shortcut ────────

  chrome.runtime.onMessage.addListener((message) => {
    // Commands API relays through background
    if (message.type === 'doTranslate') doTranslate();
    if (message.type === 'doSwitchSource') doSwitchSource();
  });

})();
```

---

### Task 4: Content CSS — Bubble & Toast Styles

**Files:**
- Create: `content.css`

**Interfaces:**
- Consumed by: `content.js` (all classes prefixed `et-`)
- Produces: Visual styles for bubble, header, body, toast

- [ ] **Step 1: Write content.css — bubble styles**

```css
/* ── Bubble ────────────────────────────────────────── */

.et-bubble {
  position: absolute;
  z-index: 99999;
  width: 360px;
  max-width: calc(100vw - 24px);
  background: rgba(30, 30, 30, 0.95);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 12px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3), 0 2px 8px rgba(0, 0, 0, 0.2);
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei", sans-serif;
  font-size: 14px;
  color: #e0e0e0;
  line-height: 1.6;
  user-select: none;
  animation: et-fade-in 0.2s ease-out;
}

@keyframes et-fade-in {
  from { opacity: 0; transform: translateY(4px); }
  to   { opacity: 1; transform: translateY(0); }
}

/* ── Header ────────────────────────────────────────── */

.et-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
  cursor: grab;
  user-select: none;
}

.et-header:active {
  cursor: grabbing;
}

.et-source-label {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 22px;
  height: 22px;
  border-radius: 50%;
  background: rgba(0, 150, 136, 0.8);
  color: #fff;
  font-size: 12px;
  font-weight: 600;
  line-height: 1;
}

.et-close {
  background: none;
  border: none;
  color: rgba(255, 255, 255, 0.5);
  font-size: 18px;
  cursor: pointer;
  padding: 0 4px;
  line-height: 1;
  transition: color 0.15s;
}

.et-close:hover {
  color: #fff;
}

/* ── Body ──────────────────────────────────────────── */

.et-body {
  padding: 10px 12px 12px;
  max-height: 300px;
  overflow-y: auto;
}

.et-original {
  color: rgba(255, 255, 255, 0.5);
  font-size: 13px;
  margin-bottom: 6px;
  word-break: break-word;
  white-space: pre-wrap;
}

.et-translation {
  color: #fff;
  font-size: 15px;
  word-break: break-word;
  white-space: pre-wrap;
}

/* Scrollbar */
.et-body::-webkit-scrollbar {
  width: 4px;
}
.et-body::-webkit-scrollbar-thumb {
  background: rgba(255, 255, 255, 0.15);
  border-radius: 2px;
}

/* ── Toast ─────────────────────────────────────────── */

.et-toast {
  position: fixed;
  top: 20px;
  left: 50%;
  transform: translateX(-50%) translateY(-20px);
  z-index: 100000;
  background: rgba(30, 30, 30, 0.9);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 8px;
  padding: 8px 20px;
  color: #e0e0e0;
  font-size: 13px;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei", sans-serif;
  white-space: nowrap;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.25s, transform 0.25s;
}

.et-toast--visible {
  opacity: 1;
  transform: translateX(-50%) translateY(0);
}
```

---

### Task 5: Popup — Settings Panel

**Files:**
- Create: `popup.html`
- Create: `popup.js`
- Create: `popup.css`

**Interfaces:**
- Produces: Source radio buttons (instant save), Youdao config form, shortcut reference
- Consumes: `chrome.runtime.sendMessage({ type: 'getConfig' })` → config
- Consumes: `chrome.runtime.sendMessage({ type: 'saveYoudao', ... })` → validation result

- [ ] **Step 1: Write popup.html**

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edge Translator</title>
  <link rel="stylesheet" href="popup.css">
</head>
<body>
  <div class="popup-container">
    <h2 class="popup-title">
      <span class="popup-icon">T</span>
      Edge Translator
    </h2>

    <!-- Source Selection -->
    <div class="section">
      <label class="section-label">翻译源</label>
      <div class="radio-group">
        <label class="radio-item">
          <input type="radio" name="source" value="google" checked>
          <span class="radio-custom"></span>
          <span class="radio-text">
            <strong>Google 翻译</strong>
            <small>零配置，即装即用</small>
          </span>
        </label>
        <label class="radio-item">
          <input type="radio" name="source" value="youdao">
          <span class="radio-custom"></span>
          <span class="radio-text">
            <strong>有道翻译</strong>
            <small>需配置 APP Key + Secret</small>
          </span>
        </label>
      </div>
    </div>

    <!-- Youdao Config -->
    <div class="section" id="youdao-section" style="display:none">
      <label class="section-label">有道配置</label>
      <div class="form-group">
        <input type="text" id="youdao-appkey" placeholder="APP Key" spellcheck="false">
      </div>
      <div class="form-group">
        <input type="password" id="youdao-secret" placeholder="Secret" spellcheck="false">
      </div>
      <button id="youdao-save" class="btn-save">保存并校验</button>
      <div id="youdao-status" class="status-msg"></div>
    </div>

    <!-- Shortcuts -->
    <div class="section shortcuts">
      <label class="section-label">快捷键</label>
      <div class="shortcut-row">
        <span class="shortcut-key">Ctrl+Shift+T</span>
        <span class="shortcut-desc">翻译选中文本</span>
      </div>
      <div class="shortcut-row">
        <span class="shortcut-key">Ctrl+Shift+Y</span>
        <span class="shortcut-desc">切换翻译源</span>
      </div>
    </div>
  </div>

  <script src="popup.js"></script>
</body>
</html>
```

- [ ] **Step 2: Write popup.js**

```js
// popup.js — Settings Panel
(async function () {
  'use strict';

  // ── Elements ────────────────────────────────────────────

  const radios = document.querySelectorAll('input[name="source"]');
  const youdaoSection = document.getElementById('youdao-section');
  const appKeyInput = document.getElementById('youdao-appkey');
  const secretInput = document.getElementById('youdao-secret');
  const saveBtn = document.getElementById('youdao-save');
  const statusEl = document.getElementById('youdao-status');

  // ── Load config ─────────────────────────────────────────

  try {
    const config = await chrome.runtime.sendMessage({ type: 'getConfig' });
    // Set radio
    const activeRadio = document.querySelector(`input[value="${config.source}"]`);
    if (activeRadio) activeRadio.checked = true;
    toggleYoudaoSection(config.source);
    // Fill youdao fields
    appKeyInput.value = config.youdaoAppKey || '';
    secretInput.value = config.youdaoSecret || '';
  } catch (err) {
    console.error('Failed to load config:', err);
  }

  // ── Source switch ───────────────────────────────────────

  radios.forEach(radio => {
    radio.addEventListener('change', async () => {
      const source = radio.value;
      toggleYoudaoSection(source);
      // Instant save
      try {
        await chrome.runtime.sendMessage({ type: 'switchSource' });
      } catch (err) {
        console.error('Failed to switch source:', err);
      }
    });
  });

  function toggleYoudaoSection(source) {
    youdaoSection.style.display = source === 'youdao' ? 'block' : 'none';
    // If Google selected, make sure storage reflects that
    if (source === 'google') {
      statusEl.textContent = '';
      statusEl.className = 'status-msg';
    }
  }

  // ── Save Youdao config ──────────────────────────────────

  saveBtn.addEventListener('click', async () => {
    const appKey = appKeyInput.value.trim();
    const secret = secretInput.value.trim();

    if (!appKey || !secret) {
      showStatus('请填写 APP Key 和 Secret', 'error');
      return;
    }

    saveBtn.disabled = true;
    saveBtn.textContent = '校验中...';
    showStatus('正在校验...', '');

    try {
      const result = await chrome.runtime.sendMessage({
        type: 'saveYoudao',
        appKey,
        secret
      });

      if (result.valid) {
        showStatus('✓ 校验通过，有道翻译已就绪', 'success');
      } else {
        showStatus('✗ ' + (result.message || '校验失败，请检查 Key'), 'error');
      }
    } catch (err) {
      showStatus('✗ 保存失败：' + err.message, 'error');
    }

    saveBtn.disabled = false;
    saveBtn.textContent = '保存并校验';
  });

  function showStatus(msg, cls) {
    statusEl.textContent = msg;
    statusEl.className = 'status-msg ' + cls;
  }

})();
```

- [ ] **Step 3: Write popup.css**

```css
/* popup.css — Settings Panel */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  width: 320px;
  background: #1e1e2e;
  color: #cdd6f4;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei", sans-serif;
  font-size: 14px;
}

.popup-container {
  padding: 16px;
}

.popup-title {
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  gap: 8px;
  color: #f5f5f5;
}

.popup-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 26px;
  height: 26px;
  border-radius: 6px;
  background: #009688;
  color: #fff;
  font-size: 14px;
  font-weight: 700;
}

/* ── Sections ─────────────────────────────── */

.section {
  margin-bottom: 16px;
}

.section-label {
  display: block;
  font-size: 11px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  color: #6c7086;
  margin-bottom: 8px;
}

/* ── Radio Group ───────────────────────────── */

.radio-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.radio-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.04);
  cursor: pointer;
  border: 1px solid transparent;
  transition: border-color 0.15s, background 0.15s;
}

.radio-item:hover {
  background: rgba(255, 255, 255, 0.06);
}

.radio-item:has(input:checked) {
  border-color: rgba(0, 150, 136, 0.5);
  background: rgba(0, 150, 136, 0.1);
}

.radio-item input[type="radio"] {
  display: none;
}

.radio-custom {
  width: 16px;
  height: 16px;
  border-radius: 50%;
  border: 2px solid rgba(255, 255, 255, 0.3);
  flex-shrink: 0;
  transition: border-color 0.15s, background 0.15s;
}

.radio-item:has(input:checked) .radio-custom {
  border-color: #009688;
  background: #009688;
  box-shadow: inset 0 0 0 3px #1e1e2e;
}

.radio-text {
  display: flex;
  flex-direction: column;
  gap: 1px;
}

.radio-text strong {
  font-size: 13px;
  color: #cdd6f4;
}

.radio-text small {
  font-size: 11px;
  color: #6c7086;
}

/* ── Form ──────────────────────────────────── */

.form-group {
  margin-bottom: 8px;
}

.form-group input {
  width: 100%;
  padding: 8px 10px;
  border-radius: 6px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  background: rgba(0, 0, 0, 0.2);
  color: #cdd6f4;
  font-size: 13px;
  font-family: inherit;
  outline: none;
  transition: border-color 0.15s;
}

.form-group input:focus {
  border-color: rgba(0, 150, 136, 0.5);
}

.form-group input::placeholder {
  color: rgba(255, 255, 255, 0.2);
}

.btn-save {
  width: 100%;
  padding: 8px;
  border: none;
  border-radius: 6px;
  background: #009688;
  color: #fff;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.15s;
  font-family: inherit;
}

.btn-save:hover {
  background: #00796b;
}

.btn-save:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.status-msg {
  margin-top: 8px;
  font-size: 12px;
  min-height: 18px;
}

.status-msg.success {
  color: #a6e3a1;
}

.status-msg.error {
  color: #f38ba8;
}

/* ── Shortcuts ─────────────────────────────── */

.shortcuts {
  border-top: 1px solid rgba(255, 255, 255, 0.06);
  padding-top: 12px;
}

.shortcut-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 4px 0;
}

.shortcut-key {
  background: rgba(255, 255, 255, 0.08);
  padding: 2px 8px;
  border-radius: 4px;
  font-family: "SF Mono", "Fira Code", "Cascadia Code", monospace;
  font-size: 12px;
  color: #f5c2e7;
}

.shortcut-desc {
  font-size: 12px;
  color: #6c7086;
}
```

---

### Task 6: Integration — Commands API Bridge & Final Polish

**Files:**
- Modify: `background.js` (add commands.onCommand listener)
- Modify: `content.js` (add runtime.onMessage for command relay)

**Interfaces:**
- Consumes: `chrome.commands.onCommand` in background
- Produces: Message relay from background → content script for commands

- [ ] **Step 1: Add commands listener to background.js**

Append to the end of `background.js`:

```js
// ── Commands API bridge ─────────────────────────────────

// Commands API fires in the service worker. We relay to the active tab's
// content script via sendMessage.
chrome.commands.onCommand.addListener(async (command) => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) return;

    if (command === 'translate') {
      chrome.tabs.sendMessage(tab.id, { type: 'doTranslate' });
    } else if (command === 'switch-source') {
      chrome.tabs.sendMessage(tab.id, { type: 'doSwitchSource' });
    }
  } catch (err) {
    // Tab may not support content scripts (e.g. edge:// pages)
    console.warn('Commands bridge: no reachable tab', err);
  }
});
```

- [ ] **Step 2: Verify content.js has the onMessage listener**

The listener was already included in Task 3 Step 4. Ensure the following is present at the bottom of `content.js`:

```js
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'doTranslate') doTranslate();
    if (message.type === 'doSwitchSource') doSwitchSource();
  });
```

- [ ] **Step 3: Review edge-responsive adjustments**

The `et-bubble` width is fixed at 360px with `max-width: calc(100vw - 24px)`. On narrow viewports, this already shrinks correctly. No additional breakpoints needed.

- [ ] **Step 4: Final file structure verification**

Verify all files exist:

```
edge-translator/
├── manifest.json          ✓
├── background.js          ✓
├── content.js             ✓
├── content.css            ✓
├── popup.html             ✓
├── popup.js               ✓
├── popup.css              ✓
├── icons/
│   ├── icon-16.png        ✓
│   ├── icon-48.png        ✓
│   └── icon-128.png       ✓
├── design.md              ✓
└── implementation-plan.md ✓
```

---
