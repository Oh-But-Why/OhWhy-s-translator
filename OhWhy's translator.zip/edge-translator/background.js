// background.js — Edge Translator Service Worker
const STORAGE_KEYS = {
  source: 'source',
  youdaoAppKey: 'youdaoAppKey',
  youdaoSecret: 'youdaoSecret'
};

const DEFAULT_SOURCE = 'google';

async function getConfig() {
  const result = await chrome.storage.local.get(STORAGE_KEYS);
  return {
    source: result.source || DEFAULT_SOURCE,
    youdaoAppKey: result.youdaoAppKey || '',
    youdaoSecret: result.youdaoSecret || ''
  };
}

// ── Google Translate ──────────────────────────────────────

async function translateWithGoogle(text) {
  const url = 'https://translate.googleapis.com/translate_a/single' +
    '?client=gtx&sl=en&tl=zh-CN&dt=t&q=' + encodeURIComponent(text);

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);

  try {
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeout);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    if (!data || !data[0]) throw new Error('Empty response');
    return data[0].map(item => item[0]).join('');
  } catch (err) {
    clearTimeout(timeout);
    if (err.name === 'AbortError') throw new Error('翻译超时');
    throw new Error('无法连接 Google 翻译');
  }
}

// ── Youdao Translate ──────────────────────────────────────

async function translateWithYoudao(text, appKey, secret) {
  if (!appKey || !secret) {
    throw new Error('请先在设置中填写有道 APP Key 和 Secret');
  }

  const salt = Date.now().toString();
  const curtime = Math.floor(Date.now() / 1000).toString();
  const input = text.length <= 20
    ? text
    : text.substring(0, 10) + text.length + text.substring(text.length - 10);

  const signStr = appKey + input + salt + curtime + secret;
  const encoder = new TextEncoder();
  const data = encoder.encode(signStr);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const sign = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

  const body = new URLSearchParams({
    q: text,
    from: 'en',
    to: 'zh-CHS',
    appKey: appKey,
    salt: salt,
    sign: sign,
    signType: 'v3',
    curtime: curtime
  });

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 5000);

  try {
    const res = await fetch('https://openapi.youdao.com/api', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString(),
      signal: controller.signal
    });
    clearTimeout(timeout);
    const json = await res.json();
    if (json.errorCode !== '0') {
      throw new Error(`有道翻译错误: ${json.errorCode}`);
    }
    return json.translation.join('');
  } catch (err) {
    clearTimeout(timeout);
    if (err.name === 'AbortError') throw new Error('翻译超时');
    throw err;
  }
}

// ── Message Handler ───────────────────────────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message).then(sendResponse);
  return true; // keep channel open for async response
});

async function handleMessage(message) {
  switch (message.type) {
    case 'translate': {
      const config = await getConfig();
      const text = message.text.trim().substring(0, 5000);
      const truncated = message.text.length > 5000;

      try {
        let translation;
        if (config.source === 'youdao') {
          translation = await translateWithYoudao(text, config.youdaoAppKey, config.youdaoSecret);
        } else {
          translation = await translateWithGoogle(text);
        }
        return {
          type: 'translation',
          text: translation + (truncated ? '\n（原文过长已截断）' : ''),
          source: config.source
        };
      } catch (err) {
        return { type: 'error', message: err.message };
      }
    }

    case 'switchSource': {
      const config = await getConfig();
      const newSource = config.source === 'google' ? 'youdao' : 'google';
      await chrome.storage.local.set({ source: newSource });
      return { type: 'sourceSwitched', source: newSource };
    }

    case 'getConfig': {
      const config = await getConfig();
      return { type: 'config', ...config };
    }

    case 'saveYoudao': {
      await chrome.storage.local.set({
        youdaoAppKey: message.appKey,
        youdaoSecret: message.secret
      });
      try {
        await translateWithYoudao('test', message.appKey, message.secret);
        return { type: 'configSaved', valid: true };
      } catch (err) {
        return { type: 'configSaved', valid: false, message: err.message };
      }
    }
  }
}

// ── Commands API bridge ─────────────────────────────────

// Commands API fires in the service worker. We relay to the active tab's
// content script via sendMessage.
chrome.commands.onCommand.addListener(async (command) => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id) return;

    if (command === 'translate') {
      chrome.tabs.sendMessage(tab.id, { type: 'doTranslate' });
    } else if (command === 'switch-source') {
      chrome.tabs.sendMessage(tab.id, { type: 'doSwitchSource' });
    }
  } catch (err) {
    // Tab may not support content scripts (e.g. edge:// pages)
    console.warn('Commands bridge: no reachable tab', err);
  }
});
