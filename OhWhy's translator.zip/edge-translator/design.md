# Edge 划词翻译插件 — 设计文档

**日期**: 2026-06-27
**状态**: 待实现

---

## 1. 概述

一个 Microsoft Edge 浏览器扩展，用户在任意网页上框选英文文本后，通过快捷键触发翻译，译文在可拖拽的气泡浮窗中显示。支持 Google 翻译和有道翻译两个翻译源，可随时切换。

### 核心原则

- **轻量**: 纯原生 JS，Manifest V3，零依赖，零构建
- **按需**: 快捷键触发，不自动请求，不浪费 API 额度
- **非侵入**: 气泡浮窗不修改页面 DOM 结构，消失后无痕

---

## 2. 架构

```
┌──────────────────────────────────────────┐
│              Edge Browser                 │
│                                           │
│  ┌──────────────┐    ┌────────────────┐   │
│  │ content.js   │◄──►│ background.js  │   │
│  │              │    │                │   │
│  │ 选中文本监听  │    │ Google 翻译     │   │
│  │ 快捷键监听    │    │ 有道翻译        │   │
│  │ 气泡 UI      │    │ 翻译源切换      │   │
│  │ 气泡拖拽     │    │ 配置读写        │   │
│  └──────┬───────┘    └───────┬────────┘   │
│         │                    │            │
│         └──── 消息传递 ──────┘            │
│                                           │
│  ┌──────────────┐                         │
│  │ popup.html   │  工具栏图标设置面板      │
│  │ popup.js     │  翻译源切换、有道 Key    │
│  └──────────────┘                         │
└──────────────────────────────────────────┘
```

### 消息协议

Content Script 与 Background Worker 之间通过 `chrome.runtime.sendMessage` 通信：

```
// Content → Background
{ type: 'translate', text: 'hello world' }
{ type: 'switchSource' }

// Background → Content
{ type: 'translation', text: '你好世界', source: 'google' }
{ type: 'sourceSwitched', source: 'youdao' }
{ type: 'error', message: '翻译失败: ...' }
```

---

## 3. 模块设计

### 3.1 Content Script (`content.js`)

运行在**每个页面**上下文，负责：

| 职责 | 实现 |
|------|------|
| **选中监听** | `mouseup` 事件 + `window.getSelection()` |
| **快捷键** | `keydown` 事件，匹配 `Ctrl+Shift+T` 和 `Ctrl+Shift+Y` |
| **语言判断** | 检测选中文本是否包含英文字母，含英文才触发 |
| **气泡 UI** | 动态创建 DOM 元素，不依赖页面样式 |
| **拖拽** | `mousedown` 在手柄上开始拖拽，`mousemove` 移动，`mouseup` 释放 |
| **位置计算** | 根据选中文本 `getBoundingClientRect()` 定位气泡，边界检测翻转 |

**气泡 DOM 结构**:
```html
<div id="et-bubble" class="et-bubble">
  <div class="et-header">        <!-- 拖拽手柄 -->
    <span class="et-source">G</span>  <!-- G=Google, Y=有道 -->
    <button class="et-close">×</button>
  </div>
  <div class="et-original">...</div>   <!-- 原文 -->
  <div class="et-translation">...</div> <!-- 译文 -->
</div>
```

- 所有 CSS 类名以 `et-` 前缀隔离
- 气泡 z-index: 99999
- 关闭方式：点 × 按钮、点气泡外空白处、按 Escape

### 3.2 Background Service Worker (`background.js`)

运行在后台，不需要持续活动。负责：

| 职责 | 实现 |
|------|------|
| **翻译调度** | 根据当前翻译源调用对应 API |
| **Google 翻译** | `fetch` 请求 `translate.googleapis.com`，解析 JSON |
| **有道翻译** | `fetch` 请求有道 API，构造签名，解析返回 |
| **配置存储** | `chrome.storage.local` 读写翻译源和 Key |
| **初始 source** | Service Worker 启动时从 storage 读取 |

**Google API 调用**:
```js
GET https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=zh-CN&dt=t&q=TEXT
→ JSON: [[["译文","原文",...],...],...]
→ 拼接 data[0][0][0] + data[0][1][0] + ...
```

**有道 API 调用**:
```js
POST https://openapi.youdao.com/api
Headers: Content-Type: application/x-www-form-urlencoded
Body: q=TEXT&from=en&to=zh-CHS&appKey=KEY&salt=SALT&sign=SIGN&signType=v3
其中 sign = SHA256(appKey + text + salt + curtime + secret)
```

### 3.3 Popup 设置面板 (`popup.html` + `popup.js`)

点击工具栏图标弹出的小面板：

```
┌──────────────────────┐
│  翻译源               │
│  ● Google   ○ 有道    │
│                       │  ← 选中即保存
│  ── 有道配置 ──       │
│  APP Key: [_______]   │  ← 仅选有道时显示
│  Secret:  [_______]   │
│  [保存]               │
│  ───────────────      │
│  快捷键               │
│  Ctrl+Shift+T  翻译   │
│  Ctrl+Shift+Y  切源   │
└──────────────────────┘
```

- 翻译源切换**即时生效**（不需要额外点保存）
- 有道 Key 输入后才需点保存，保存时做连通性校验
- 尺寸：320px × 约 280px

---

## 4. 数据流

```
选中英文 → 按 Ctrl+Shift+T
  └→ content.js 提取选中文本
    └→ chrome.runtime.sendMessage({type:'translate', text})
      └→ background.js 收到消息
        ├→ 查 storage 当前翻译源
        ├→ 调用对应 API
        │   ├→ Google: GET translate.googleapis.com
        │   └→ 有道: POST openapi.youdao.com
        ├→ 翻译成功？
        │   ├→ 是: sendMessage({type:'translation', text, source})
        │   └→ 否: sendMessage({type:'error', message})
        └→ content.js 收到翻译结果
          ├→ 创建/更新气泡显示译文
          └→ 定位气泡在选中文本附近

按 Ctrl+Shift+Y
  └→ content.js → background.js
    └→ 读当前源 → 切换 → 写 storage → 返回新源
      └→ content.js 显示 toast 提示 "已切换到 Google / 有道"
```

---

## 5. 文件结构

```
edge-translator/
├── manifest.json        # MV3 manifest
├── background.js        # Service Worker
├── content.js           # Content Script（注入所有页面）
├── content.css          # 气泡样式
├── popup.html           # 设置面板 HTML
├── popup.js             # 设置面板逻辑
├── popup.css            # 设置面板样式
├── icons/
│   ├── icon-16.png      # 工具栏图标
│   ├── icon-48.png      # 扩展管理图标
│   └── icon-128.png     # 商店图标
└── design.md            # 本文件
```

---

## 6. Manifest 权限

```json
{
  "manifest_version": 3,
  "name": "Edge Translator",
  "version": "1.0.0",
  "description": "划词翻译：框选英文 → 快捷键翻译 → 气泡显示",
  "permissions": ["storage"],
  "host_permissions": [
    "https://translate.googleapis.com/*",
    "https://openapi.youdao.com/*"
  ],
  "content_scripts": [{
    "matches": ["<all_urls>"],
    "js": ["content.js"],
    "css": ["content.css"]
  }],
  "background": {
    "service_worker": "background.js"
  },
  "action": {
    "default_popup": "popup.html",
    "default_icon": { ... }
  },
  "icons": { ... },
  "commands": {
    "translate": {
      "suggested_key": { "default": "Ctrl+Shift+T" },
      "description": "翻译选中文本"
    },
    "switch-source": {
      "suggested_key": { "default": "Ctrl+Shift+Y" },
      "description": "切换翻译源"
    }
  }
}
```

### 为什么用 `commands` API 而不是 `keydown`？

- `commands` API 注册的快捷键可被用户在 `edge://extensions/shortcuts` 中自定义
- 但 `commands` 仅支持 4 个快捷键，我们正好用 2 个
- Content script 中仍需 `keydown` 兜底，因为 `commands` 在某些页面（如 chrome:// 内部页）不生效

两者结合：`commands` 收到后触发，content script 中 `keydown` 也作为后备。

---

## 7. 错误处理

| 场景 | 处理 |
|------|------|
| Google API 无法访问（国内网络） | 气泡显示 "翻译失败：无法连接 Google，请切换到有道" |
| 有道配置错误（Key 无效） | Popup 保存时提示 "校验失败"；翻译时气泡提示 "有道 Key 无效" |
| 网络超时（5 秒） | AbortController 取消请求，提示 "翻译超时" |
| 选中文本为空/全是中文 | 不弹气泡，或提示 "未检测到英文文本" |
| 文本过长（>5000 字符） | 截断为 5000 字符后翻译，气泡底部标注 "原文过长已截断" |

---

## 8. 自检清单

- [ ] placeholder / TODO 扫描：无
- [ ] 内部一致性：消息协议各模块一致 ✓
- [ ] 范围可控：6 个核心文件，单一日志插件 ✓
- [ ] 无歧义：所有交互有确定的行为 ✓
